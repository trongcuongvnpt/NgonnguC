#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 
{
	
	int x, y;
 	char a = 'y';
 	x = y = 0;
 	if (a == 'y')
 	{
 		x += 5;
 		printf("The numbers are %d and \t%d", x, y);
	}
}
